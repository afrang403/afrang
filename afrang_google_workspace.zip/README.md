# Afrang Website - Google Apps Script Backend
Upload files directly to GitHub Pages.